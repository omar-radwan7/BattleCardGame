package game.presentation.components.labels;

import javax.swing.JLabel;

public class MenuLabel extends JLabel {
    public MenuLabel() {
        super();
        // Configure menu label here
    }
}
