package game.presentation.components.buttons;

import javax.swing.JButton;

public class GameNextButton extends JButton {
    public GameNextButton() {
        super();
        // Configure game button presentation and logic here
    }
}
