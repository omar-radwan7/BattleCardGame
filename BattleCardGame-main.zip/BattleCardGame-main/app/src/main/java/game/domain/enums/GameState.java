package game.domain.enums;

public enum GameState {
    RUNNING,
    FINISHED,
}
