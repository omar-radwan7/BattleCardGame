package game.domain.enums;

public enum GamePanels {
    MENU,
    GAME,
    FINAL
}
