package game.domain.enums;

public enum CardSuit {
    CLUBS,
    DIAMONDS,
    HEARTS,
    SPADES,
}
